<?php
$language['ERR_NO_EMAIL']='Musíte zadat email';
$language['ERR_INV_EMAIL']='Vložte platný email';
$language['ERR_NO_CAPTCHA']='Vložte obrázkový kód';
$language['IMAGE_CODE']='Obrázkový kód';
$language['SECURITY_CODE']='Odpovězte na otázku';
$language['RECOVER_EMAIL_1']="\n".'Pokoušíte se resetovat heslo k účtu spojeném s emailovou adresou (%s) .'."\n\n".'Požadavek přišel z %s.'."\n\n".'Jestliže jste to nebyli vy, ignorujte tento email. Prosím neodpovídejte.'."\n\n".'Pro resetování hesla prosím klikněte na následující odkaz:'."\n\n".'%s'."\n\n".'Heslo bude vyresetováno a přihlašovací údaje budou obratem zaslány emailem.'."\n--\n".'%s';
$language['RECOVER_EMAIL_2']="\n".'Na základě vaší žádosti jsme vygenerovali nové heslo k vašemu účtu.'."\n\n".'Přihlašovací údaje k účtu:'."\n\n\t".'Uživatelské jméno: %s'."\n\n\t".'Heslo: %s'."\n\n".'Můžete se přihlásit zde: %s'."\n\n--\n".'%s';
?>