<?php
$language['ERR_NO_TITLE']='Pro novinku je potřeba vložit nadpis!';
?>