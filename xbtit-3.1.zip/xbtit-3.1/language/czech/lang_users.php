<?php

// ENGLISH USERS.PHP FILE

$language['FIND_USER']       = 'Najít uživatele';
$language['USER_LEVEL']      = 'Úroveň uživatele';
$language['ALL']             = 'Všichni';
$language['SEARCH']          = 'Vyhledat';
$language['USER_NAME']       = 'Uživatelské jméno';
$language['USER_LEVEL']      = 'Úroveň uživatele';
$language['USER_JOINED']     = 'Přidal se';
$language['USER_LASTACCESS'] = 'Poslední přihlášení';
$language['USER_COUNTRY']    = 'Země';
$language['RATIO']           = 'Ratio';
$language['USERS_PM']        = 'PM';
$language['EDIT']            = 'Upravit';
$language['DELETE']          = 'Smazat';
$language['NO_USERS_FOUND']  = 'Žádný uživatel nenalezen!';
$language['UNKNOWN']         = 'Unknown';
?>