<?php
$language['INSERT_USERNAME']='Musíte zadat uživatelské jméno!';
$language['INSERT_PASSWORD']='Musíte zadat heslo!';
?>