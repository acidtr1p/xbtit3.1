<?php
$language['NOT_SHA']='SHA1 funkce není dostupná. Požadováné alespoň PHP 4.3.0.';
$language['NOT_AUTHORIZED_UPLOAD']='Nejste oprávnění uploadovat!';
$language['FILE_UPLOAD_ERROR_1']='Nahraný soubor nelze přečíst';
$language['FILE_UPLOAD_ERROR_3']='Soubor má nulovou velikost';
$language['FACOLTATIVE']='dobrovolné';
$language['FILE_UPLOAD_ERROR_2']='Chyby nahrávání';
$language['ERR_PARSER']='Ve vašem torrentu se vyskytuje chyba. Nebyl přijat.';
$language['WRITE_CATEGORY']='Specifikujte kategorii torrentu...';
$language['DOWNLOAD']='Stáhnout';
$language['MSG_UP_SUCCESS']='Nahrání úspěšné! Torrent byl přidán.';
$language['MSG_DOWNLOAD_PID']='PID system je aktivní. Stáhněte torrent s vaším PID';
$language['EMPTY_DESCRIPTION']='Musíte vložit popis!';
$language['EMPTY_ANNOUNCE']='Announce je prázdná';
$language['FILE_UPLOAD_ERROR_1']='Nelze přečíst nahraný soubor';
$language['FILE_UPLOAD_ERROR_2']='Chyby nahrávání';
$language['FILE_UPLOAD_ERROR_3']='Soubor má nulovou velikost';
$language['NO_SHA_NO_UP']='Nahrávání není možné - žádná SHA1 funkce.';
$language['NOT_SHA']='SHA1 funkce není dostupná. Požadováné alespoň PHP 4.3.0.';
$language['ERR_PARSER']='Ve vašem torrentu se vyskytuje chyba. Nebyl přijat.';
$language['WRITE_CATEGORY']='Specifikujte kategorii torrentu...';
$language['ERR_HASH']='Info hash MUSÍ mít přesně 40 hex bytů.';
$language['ERR_EXTERNAL_NOT_ALLOWED']='Externí torrenty nejsou povoleny';
$language['ERR_MOVING_TORR']='Chyby přesouvání torrentu...';
$language['ERR_ALREADY_EXIST']='Tento torrent se již nachází v databázi.';
$language['MSG_DOWNLOAD_PID']='PID system je aktivní. Stáhněte torrent s vaším PID';
$language['MSG_UP_SUCCESS']='Nahrání úspěšné! Torrent byl přidán.';
?>