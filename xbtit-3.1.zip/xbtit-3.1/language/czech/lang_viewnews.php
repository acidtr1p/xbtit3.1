<?php

// VIEWNEWS.PHP LANGUAGE FILE

$language['POSTED_BY']   = 'Vložil';
$language['POSTED_DATE'] = 'Datum';
$language['TITLE']       = 'Nadpis';
$language['ADD']         = 'Přidat';
?>