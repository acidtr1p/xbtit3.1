<?php
$language['PEER_PROGRESS']='Progres';
$language['PEER_COUNTRY']='Země';
$language['PEER_PORT']='Port';
$language['PEER_STATUS']='Status';
$language['PEER_CLIENT']='Klient';
$language['NO_PEERS']='Žádní peers';
?>