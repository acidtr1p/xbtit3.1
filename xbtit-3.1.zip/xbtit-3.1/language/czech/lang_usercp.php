<?php
$language['DELETE_READED']='Smazat';
$language['USER_LANGUE']='Jazyk';
$language['USER_STYLE']='Styl';
$language['CURRENTLY_PEER']='Momentálně seedujete nebo leechujete nějaký torrent.';
$language['STOP_PEER']='Musíte ukončit klienta.';
$language['USER_PWD_AGAIN']='Zopakovat heslo';
$language['EMAIL_FAILED']='Odeslání emailu selhalo!';
$language['NO_SUBJECT']='Žádný předmět';
$language['MUST_ENTER_PASSWORD']='<br /><font color="#FF0000"><strong>Pro provedení změny nastavení vložte heslo.</strong></font>';
$language['ERR_PASS_WRONG']='Heslo nezadáno nebo je chybné, profil nelze aktualizovat.';
$language['MSG_DEL_ALL_PM']='Jestliže vyberete zprávy (PMs), které nebyly přečteny, nebudou smazány';
$language['ERR_PM_GUEST']='Nelze odeslat zprávu (PM) sám sobě nebo uživateli hosta!';
?>