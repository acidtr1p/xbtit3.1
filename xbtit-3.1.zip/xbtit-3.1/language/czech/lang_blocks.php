<?php
$language['BLOCK_USER']='Info o uživateli';
$language['BLOCK_INFO']='Info o Trackeru';
$language['BLOCK_MAINMENU']=''; # this is the Main Menu no name needed, some dipshit took this out ... not nice!!
# We leave this name (drop down menu) blank so it doesnt use the block head showing its name, it looks unsightly and non professional imho!! TreetopClimber
$language['BLOCK_DDMENU']='';
$language['BLOCK_MENU']='Hlavní Menu'; # block menu needs the name
$language['BLOCK_CALENDAR']='Kalendář';
$language['BLOCK_CLOCK']='Hodiny';
$language['BLOCK_FORUM']='Fórum';
$language['BLOCK_LASTMEMBER']='Poslední člen';
$language['BLOCK_ONLINE']='Online';
$language['BLOCK_ONTODAY']='Dneska';
$language['BLOCK_SHOUTBOX']='Shout Box';
$language['BLOCK_TOPTORRENTS']='Top Torrenty';
$language['BLOCK_LASTTORRENTS']='Poslední Upload';
$language['BLOCK_NEWS']='Nejnovější zprávy';
$language['BLOCK_SERVERLOAD']='Zátěž serveru';
$language['BLOCK_POLL']='Anekta';
$language['BLOCK_SEEDWANTED']='Torrenty s žádostí o seed';
$language['BLOCK_PAYPAL']='Podpořte nás';
$language['BLOCK_MAINTRACKERTOOLBAR']='Hlavní Tracker Toolbar';
$language['BLOCK_MAINUSERTOOLBAR']='Hlavní User Toolbar';
$language['WELCOME_LASTUSER']=' Vítejte na The Trackeru ';
$language['BLOCK_MINCLASSVIEW']='Minimumální hodnost, která může vidět';
$language['BLOCK_MAXCLASSVIEW']='Maximální hodnost, která může vidět';
?>