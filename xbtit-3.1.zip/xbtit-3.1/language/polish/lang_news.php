<?php
$language["ERR_NO_TITLE"]="Musisz wpisać Tytuł swojego newsa";
?>