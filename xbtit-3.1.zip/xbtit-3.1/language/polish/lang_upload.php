<?php
$language["NOT_SHA"]="Funkcja SHA1 niedostępna. Musisz mieć PHP 4.3.0 lub nowszy.";
$language["NOT_AUTHORIZED_UPLOAD"]="Nie masz uprawnień do wstawiania torrentów!";
$language["FILE_UPLOAD_ERROR_1"]="Nie można odczytać wstawionego pliku.";
$language["FILE_UPLOAD_ERROR_3"]="Plik ma zerowy rozmiar.";
$language["FACOLTATIVE"]="Opcjonalny";
$language["FILE_UPLOAD_ERROR_2"]="Błąd przesyłania pliku";
$language["ERR_PARSER"]="W twoim torrencie wystąpiły pewne błędy. Parser go nie zaakceptował.";
$language["WRITE_CATEGORY"]="Musisz wybrać kategorię torrenta...";
$language["DOWNLOAD"]="Pobierz";
$language["MSG_UP_SUCCESS"]="Przesyłanie zakończone pomyślnie! Torrent został dodany.";
$language["MSG_DOWNLOAD_PID"]="System PID aktywny, pobierz torrenta ze swoim PID.";
$language["EMPTY_DESCRIPTION"]="Musisz dodać opis pliku!";
$language["EMPTY_ANNOUNCE"]="Announce jest pusty";
$language["FILE_UPLOAD_ERROR_1"]="Nie można odczytać przesłanego pliku.";
$language["FILE_UPLOAD_ERROR_2"]="Błąd przesyłania pliku";
$language["FILE_UPLOAD_ERROR_3"]="Plik ma zerowy rozmiar.";
$language["NO_SHA_NO_UP"]="Przesyłanie plików niemożliwe - brak funkcji SHA1.";
$language["NOT_SHA"]="Funkcja SHA1 niedostępna. Musisz mieć PHP 4.3.0 lub nowszy.";
$language["ERR_PARSER"]="W twoim torrencie wystąpiły pewne błędy. Parser go nie zaakceptował.";
$language["WRITE_CATEGORY"]="Musisz wybrać kategorię torrenta...";
$language["ERR_HASH"]="Info hash MUSI mieć dokładnie 40 hex bajtów.";
$language["ERR_EXTERNAL_NOT_ALLOWED"]="Zewnętrzne torrenty niedozwolone";
$language["ERR_MOVING_TORR"]="Błąd przenoszenia torrenta...";
$language["ERR_ALREADY_EXIST"]="Ten torrent już istnieje w bazie danych.";
$language["MSG_DOWNLOAD_PID"]="System PID aktywny, pobierz torrenta ze swoim PID.";
$language["MSG_UP_SUCCESS"]="Przesyłanie zakończone pomyślnie! Torrent został dodany.";
?>