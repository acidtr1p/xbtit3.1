<?php
$language["DELETE_READED"]="Usuń przeczytane";
$language["USER_LANGUE"]="Język";
$language["USER_STYLE"]="Styl";
$language["CURRENTLY_PEER"]="Aktualnie seedujesz bądź ściągasz jakieś torrenty.";
$language["STOP_PEER"]="Musisz wyłączyć swojego klienta.";
$language["USER_PWD_AGAIN"]="Powtórz hasło";
$language["EMAIL_FAILED"]="Wysłanie emaila zakończone niepowodzeniem!";
$language["NO_SUBJECT"]="Brak tematu";
$language["MUST_ENTER_PASSWORD"]="<br /><font color=\"#FF0000\"><strong>Musisz wpisać hasło, aby zmienić powyższe ustawienia.</strong></font>";
$language["ERR_PASS_WRONG"]="Hasło puste lub nieprawidłowe, nie można uaktualnić profilu.";
$language["MSG_DEL_ALL_PM"]="Jeżeli wybierzesz PM-y, które nie zostały przeczytane, nie zostaną one usunięte.";
$language["ERR_PM_GUEST"]="Przepraszamy, nie można wysyłać PM do konta gościa lub samego siebie!";
?>