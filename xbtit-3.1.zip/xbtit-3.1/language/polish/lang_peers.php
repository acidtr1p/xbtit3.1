<?php
$language["PEER_PROGRESS"]="Postęp";
$language["PEER_COUNTRY"]="Kraj";
$language["PEER_PORT"]="Port";
$language["PEER_STATUS"]="Status";
$language["PEER_CLIENT"]="Klient";
$language["NO_PEERS"]="Brak peerów";
?>