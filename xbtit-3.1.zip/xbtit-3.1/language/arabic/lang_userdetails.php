<?php

// USERDETAILS.PHP LANGUAGE FILE

$language['USERNAME']           = 'المستخدم';
$language['EMAIL']              = 'البريد';
$language['LAST_IP']            = 'Ipآخر';
$language['USER_LEVEL']         = 'الرتبه';
$language['USER_JOINED']        = 'التسجيل';
$language['USER_LASTACCESS']    = 'آخر دخول';
$language['PEER_COUNTRY']       = 'الدولة';
$language['USER_LOCAL_TIME']    = 'توقيت المستخدم المحلي';
$language['DOWNLOADED']         = 'نزل';
$language['UPLOADED']           = 'رفع';
$language['RATIO']              = 'النسبة';
$language['FORUM']              = 'منتدى';
$language['POSTS']              = 'مشاركات';
$language['POSTS_PER_DAY']      = 'مشاركة باليوم%s ';
$language['TORRENTS']           = 'التورينتات';
$language['FILE']               = 'ملف';
$language['ADDED']              = 'اضيف';
$language['SIZE']               = 'الحجم';
$language['SHORT_S']            = 'سيدرس';
$language['SHORT_L']            = 'ليشرس';
$language['SHORT_C']            = 'منتهي';
$language['NO_TORR_UP_USER']    = 'لم يقم المستخدم برفع اي ملفات تورينت';
$language['ACTIVE_TORRENT']     = 'التورينتات الفعالة حالياً';
$language['PEER_STATUS']        = 'الحالة';
$language['NO_ACTIVE_TORR']     = 'لا توجد تورينتات فعالة في الوقت الحالي';
$language['PEER_CLIENT']        = 'البرنامج';
$language['EDIT']               = 'تعديل';
$language['DELETE']             = 'الخار';
$language['PM']                 = 'رخ';
$language['BACK']               = 'الخلف';
$language['NO_HISTORY']         = 'لا يوجد تاريخ للعرض';
$language['GUEST_DETAILS']      = 'لا يمكنك عرض تفاصيل حساب الزائر';
?>