<?php
$language['ACCOUNT_CREATED']='تم انشاء الحساب';
$language['USER_NAME']='مستخدم';
$language['USER_PWD_AGAIN']='كرر كلمة السر';
$language['USER_PWD']='كلمة السر';
$language['USER_STYLE']='الشكل';
$language['USER_LANGUE']='اللغة';
$language['IMAGE_CODE']='نص الصورة';
$language['INSERT_USERNAME']='عليك ادخال اسم مستخدم';
$language['INSERT_PASSWORD']='عليك ادخال كلمة السر';
$language['DIF_PASSWORDS']='كلمات السر لا تتطابق';
$language['ERR_NO_EMAIL']='عليك ادخال بريد الكتروني صالح تاكد من بريدك مرة اخرى';
$language['USER_EMAIL_AGAIN']='كرر البريد';
$language['ERR_NO_EMAIL_AGAIN']='كرر البريد';
$language['DIF_EMAIL']='حقول البريد الالكتروني لا تتطابق';
$language['SECURITY_CODE']='اجب على السوال';
# Password strength
$language['WEEK']='كلمة سر ضعيفة';
$language['MEDIUM']='كلمة سر متوسطه';
$language['SAFE']='كلمة سر آمنة';
$language['STRONG']='كلمة سر قوية';
$language["ERR_GENERIC"]='خطاء عام '.((is_object($GLOBALS['conn'])) ? mysqli_error($GLOBALS['conn']) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false));
?>