<?php
$language['NOT_SHA']='دالة SHA1 موجود في اصدار بي اتش بي 4.3 وما فوق';
$language['NOT_AUTHORIZED_UPLOAD']='ليس مصرح لك برفع الملفات';
$language['FILE_UPLOAD_ERROR_1']='لا يمكن قراءة الملف المرفوع';
$language['FILE_UPLOAD_ERROR_3']='حجم الملف صفر';
$language['FACOLTATIVE']='خياري';
$language['FILE_UPLOAD_ERROR_2']='خطاء عند رفع الملف';
$language['ERR_PARSER']='هناك خطاء في ملف التورينت المرفوع';
$language['WRITE_CATEGORY']='عليك تحديد قسم من الاقسام';
$language['DOWNLOAD']='تحميل';
$language['MSG_UP_SUCCESS']='عملية الرفع ناجة. تم اضافة ملف  التورينت';
$language['MSG_DOWNLOAD_PID']='خاصية رقم البيد مفعلة.. عليك تحميل ملف التورينت الذي يحتوي على رقمك الخاص';
$language['EMPTY_DESCRIPTION']='عليك ادخال وصف';
$language['EMPTY_ANNOUNCE']='المعلن فاضي الرجاء وضع وصلة معلن التراكر';
$language['FILE_UPLOAD_ERROR_1']='لا يمكن قراءة الملف المرفوع';
$language['FILE_UPLOAD_ERROR_2']='خطاء في رفع الملف';
$language['FILE_UPLOAD_ERROR_3']='حجم الملف صفر';
$language['NO_SHA_NO_UP']='File uploading not available - no SHA1 function.';
$language['NOT_SHA']='SHA1 function not available. You need PHP 4.3.0 or better.';
$language['ERR_PARSER']='هناك خطاء في ملف التورينت المرفوع';
$language['WRITE_CATEGORY']='عليك تحديد قسم من الاقسام';
$language['ERR_HASH']='Info hash MUST be exactly 40 hex bytes.';
$language['ERR_EXTERNAL_NOT_ALLOWED']='التورينتات الخارجية غير مسموح بها';
$language['ERR_MOVING_TORR']='خطاء عند نقل ملف التورينت';
$language['ERR_ALREADY_EXIST']='من المحتمل ان هذا التورينت موجود في التراكر من قبل';
$language['MSG_DOWNLOAD_PID']='خاصية رقم البيد مفعلة .. عليك تحميل ملف التورينت الذي يحتوي على رقمك الخاص';
$language['MSG_UP_SUCCESS']='عملية الرفع ناجحة. تم اضافة ملف التورينت. تاكد من قيامك بعملية السيد';
?>