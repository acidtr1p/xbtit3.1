<?php
$language["NOT_SHA"]="SHA1 η λειτουργία δεν είναι διαθέσιμη. Χρειάζεστε PHP 4.3.0 η καλύτερο.";
$language["NOT_AUTHORIZED_UPLOAD"]="Δεν επιτρέπεται να ανεβάσετε (upload)!";
$language["FILE_UPLOAD_ERROR_1"]="Δεν μπορεί να διαβαστεί το ανεβασμένο αρχείο";
$language["FILE_UPLOAD_ERROR_3"]="Το αρχείο εχει μηδενικό μέγεθος";
$language["FACOLTATIVE"]="Της επιλογής σου";
$language["FILE_UPLOAD_ERROR_2"]="Αρχείο ανεβασμένο λάθος";
$language["ERR_PARSER"]="Φαίνεται να υπάρχει ενα λάθος στο torrents σας. Ο κατατμητής δεν το δέχθηκε.";
$language["WRITE_CATEGORY"]="Πρέπει να κάνετε συγκεκριμένη την κατηγορία torrent...";
$language["DOWNLOAD"]="Κατέβασμα";
$language["MSG_UP_SUCCESS"]="Ανέβασμα επιτυχημένο! Το torrent προσθέθηκε.";
$language["MSG_DOWNLOAD_PID"]="PID Σύστημα ενεργό πάρτε τα torrent σας με το PID σας";
$language["EMPTY_DESCRIPTION"]="Πρέπει να βάλετε μια περιγραφή!";
$language["EMPTY_ANNOUNCE"]="Η ανακοίνωση είναι άδεια";
$language["FILE_UPLOAD_ERROR_1"]="Δεν μπορεί να διαβαστεί το ανεβασμένο αρχείο";
$language["FILE_UPLOAD_ERROR_2"]="Αρχείο ανεβασμένο λάθος";
$language["FILE_UPLOAD_ERROR_3"]="Το αρχείο εχει μηδενικό μέγεθος";
$language["NO_SHA_NO_UP"]="Το ανέβασμα του αρχείου δεν είναι διαθέσιμο - Δεν υπάρχει SHA1 λειτουργία.";
$language["NOT_SHA"]="SHA1 η λειτουργία δεν είναι διαθέσιμη. Χρειάζεστε PHP 4.3.0 η καλύτερο.";
$language["ERR_PARSER"]="Φαίνεται να υπάρχει ενα λάθος στο torrents σας. Ο κατατμητής δεν το δέχθηκε.";
$language["WRITE_CATEGORY"]="Πρέπει να κάνετε συγκεκριμένη την κατηγορία torrent...";
$language["ERR_HASH"]="Η πληροφορία hash ΠΡΕΠΕΙ να είναι ακριβώς 40 hex bytes.";
$language["ERR_EXTERNAL_NOT_ALLOWED"]="Δεν επιτρέπονται τα εξωτερικά torrents";
$language["ERR_MOVING_TORR"]="Λάθος μετακίνηση torrent...";
$language["ERR_ALREADY_EXIST"]="Αυτό το torrent μπορεί να υπάρχει ήδη στη βάση δεδομένων μας.";
$language["MSG_DOWNLOAD_PID"]="PID Σύστημα ενεργό πάρτε τα torrent σας με το PID σας";
$language["MSG_UP_SUCCESS"]="Ανέβασμα επιτυχημένο! Το torrent προσθέθηκε.";
?>