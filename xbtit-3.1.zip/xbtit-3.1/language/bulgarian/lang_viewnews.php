<?php

// VIEWNEWS.PHP LANGUAGE FILE

$language["POSTED_BY"]   = "Публикувано от";
$language["POSTED_DATE"] = "Дата на публикуване";
$language["TITLE"]       = "Заглавие";
$language["ADD"]         = "Добави";
?>