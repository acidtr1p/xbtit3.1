<?php
$language["ACCOUNT_CREATED"]="Акаунтът е създаден успешно!";
$language["USER_NAME"]="Потребител";
$language["USER_PWD_AGAIN"]="Повторете паролата";
$language["USER_PWD"]="Парола";
$language["USER_STYLE"]="Стил";
$language["USER_LANGUE"]="Език";
$language["IMAGE_CODE"]="Изображение с код";
$language["INSERT_USERNAME"]="Трябва да въведете име!";
$language["INSERT_PASSWORD"]="Трябва да въведете парола!";
$language["DIF_PASSWORDS"]="Въведените пароли не съвпадат!";
$language["ERR_NO_EMAIL"]="Трябва да въведете валиден e-mail адрес";
$language["USER_EMAIL_AGAIN"]="Повторете e-mail адреса";
$language["ERR_NO_EMAIL_AGAIN"]="Повторете e-mail aдреса";
$language["DIF_EMAIL"]="Е-mail адресите не съвпадат!";
$language["SECURITY_CODE"]="Отговорете на въпроса";
# Password strength
$language["WEEK"]="Слаба";
$language["MEDIUM"]="Средна";
$language["SAFE"]="Сигурна";
$language["STRONG"]="Силна";
$language["ERR_GENERIC"]="Нестандартна грешка: ".((is_object($GLOBALS['conn'])) ? mysqli_error($GLOBALS['conn']) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false));
?>