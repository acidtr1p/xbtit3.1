<?php
$language["BLOCK_USER"]="Потребителска информация";
$language["BLOCK_INFO"]="Информация за тракера";
$language["BLOCK_MENU"]="Главно меню";
$language["BLOCK_CLOCK"]="Часовник";
$language["BLOCK_FORUM"]="Форум";
$language["BLOCK_LASTMEMBER"]="Най-новият потребител";
$language["BLOCK_ONLINE"]="Онлайн";
$language["BLOCK_ONTODAY"]="Онлайн днес";
$language["BLOCK_SHOUTBOX"]="Чат";
$language["BLOCK_TOPTORRENTS"]="Най-добри торенти";
$language["BLOCK_LASTTORRENTS"]="Последно качени";
$language["BLOCK_NEWS"]="Последни новини";
$language["BLOCK_SERVERLOAD"]="Натоварване на тракера";
$language["BLOCK_POLL"]="Анкета";
$language["BLOCK_SEEDWANTED"]="Торенти, искащи сийд";
$language["BLOCK_PAYPAL"]="Подкрепете ни";
$language["BLOCK_MAINTRACKERTOOLBAR"]="Главно меню на тракера";
$language["BLOCK_MAINUSERTOOLBAR"]="Главно потребителско меню";
$language["WELCOME_LASTUSER"]=" Добре дошли в нашия тракер, ";
$language["BLOCK_MINCLASSVIEW"]="Минимален ранг";
$language["BLOCK_MAXCLASSVIEW"]="Максимален ранг";
?>