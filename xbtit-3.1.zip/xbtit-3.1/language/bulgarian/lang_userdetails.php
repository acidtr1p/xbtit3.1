<?php

// USERDETAILS.PHP LANGUAGE FILE

$language["USERNAME"]           = "Име";
$language["EMAIL"]              = "E-mail";
$language["LAST_IP"]            = "Последно IP";
$language["USER_LEVEL"]         = "Потребителско ниво";
$language["USER_JOINED"]        = "Регистриран на";
$language["USER_LASTACCESS"]    = "Последен достъп на";
$language["PEER_COUNTRY"]       = "Държава";
$language["USER_LOCAL_TIME"]    = "Местно време";
$language["DOWNLOADED"]         = "Свалено";
$language["UPLOADED"]           = "Качено";
$language["RATIO"]              = "Рейтинг";
$language["FORUM"]              = "Форум";
$language["POSTS"]              = "постове";
$language["POSTS_PER_DAY"]      = "%s поста на ден";
$language["TORRENTS"]           = "Торенти";
$language["FILE"]               = "Файл";
$language["ADDED"]              = "Добавен";
$language["SIZE"]               = "Големина";
$language["SHORT_S"]            = "С";
$language["SHORT_L"]            = "Л";
$language["SHORT_C"]            = "З";
$language["NO_TORR_UP_USER"]    = "Потребителят не е качвал торенти!";
$language["ACTIVE_TORRENT"]     = "Активни торенти";
$language["PEER_STATUS"]        = "Статус";
$language["NO_ACTIVE_TORR"]     = "Няма активни торенти";
$language["PEER_CLIENT"]        = "Клиент";
$language["EDIT"]               = "Редактирай";
$language["DELETE"]             = "Изтрий";
$language["PM"]                 = "ЛС";
$language["BACK"]               = "Назад";
$language["NO_HISTORY"]         = "Няма история...";
?>