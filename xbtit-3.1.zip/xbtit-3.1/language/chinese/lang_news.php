<?php
//中文翻译:ziggear
//你可以自由修改和发布，但不要删除注释和作者信息。
$language['ERR_NO_TITLE']='你需要为公告加一个标题';
?>