<?php
//中文翻译:ziggear
//你可以自由修改和发布，但不要删除注释和作者信息。
$language['ACCOUNT_CREATED']='帐号已创建';
$language['USER_NAME']='用户名';
$language['USER_PWD_AGAIN']='重复密码';
$language['USER_PWD']='密码';
$language['USER_STYLE']='默认主题';
$language['USER_LANGUE']='语言选择';
$language['IMAGE_CODE']='验证码';
$language['INSERT_USERNAME']='你必须输入用户名!';
$language['INSERT_PASSWORD']='你必须输入密码!';
$language['DIF_PASSWORDS']='两次输入的密码不匹配!';
$language['ERR_NO_EMAIL']='email地址不合法';
$language['USER_EMAIL_AGAIN']='重复email地址';
$language['ERR_NO_EMAIL_AGAIN']='重复输入email地址';
$language['DIF_EMAIL']='两次输入的email地址不匹配!';
$language['SECURITY_CODE']='请回答问题';
# Password strength
$language['WEEK']='弱';
$language['MEDIUM']='中';
$language['SAFE']='强';
$language['STRONG']='极强';
$language["ERR_GENERIC"]='一般性错误: '.((is_object($GLOBALS['conn'])) ? mysqli_error($GLOBALS['conn']) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false));
?>