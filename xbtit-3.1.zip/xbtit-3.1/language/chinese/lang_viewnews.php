<?php
//中文翻译:ziggear
//你可以自由修改和发布，但不要删除注释和作者信息。

$language['POSTED_BY']   = '发布者:';
$language['POSTED_DATE'] = '发布时间:';
$language['TITLE']       = '标题';
$language['ADD']         = '新公告';
?>