<?php
//中文翻译:ziggear
//你可以自由修改和发布，但不要删除注释和作者信息。

$language['FIND_USER']       = '搜索用户';
$language['USER_LEVEL']      = '用户组';
$language['ALL']             = '全部';
$language['SEARCH']          = '搜索';
$language['USER_NAME']       = '用户名';
$language['USER_LEVEL']      = '用户组';
$language['USER_JOINED']     = '注册日期';
$language['USER_LASTACCESS'] = '最后访问';
$language['USER_COUNTRY']    = '来自';
$language['RATIO']           = '比率';
$language['USERS_PM']        = '站内信';
$language['EDIT']            = '编辑';
$language['DELETE']          = '删除';
$language['NO_USERS_FOUND']  = '没有符合条件的用户!';
$language['UNKNOWN']         = '未知';
?>