<?php
$language["DOWNLOAD_CHECK"]="Hent torrent";
$language["TORRENT_READY"]="Torrent filen kan nu hentes";
$language["TORRENT_NOT_READY_1"]="Din ratio er under ";
$language["TORRENT_NOT_READY_2"]=" så du kan desværre ikke hente denne torrent";
$language["YOUR_RATIO"]="Din ratio";
$language["CANT_DOWNLOAD"]="Du bliver nødt til at hæve din ratio for at kunne hente denne torrent.";
?>