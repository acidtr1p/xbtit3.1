<?php
$language['INSERT_USERNAME']='Du skal indtaste et brugernavn!';
$language['INSERT_PASSWORD']='Du skal indtaste et kodeord!';
?>