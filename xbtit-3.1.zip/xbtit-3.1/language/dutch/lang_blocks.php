<?php
$language["BLOCK_USER"]="Gebruikers Info";
$language["BLOCK_INFO"]="Tracker Info";
$language["BLOCK_MENU"]="Hoofdmenu";
$language["BLOCK_CLOCK"]="Klok";
$language["BLOCK_FORUM"]="Forum";
$language["BLOCK_LASTMEMBER"]="Laatste lid";
$language["BLOCK_ONLINE"]="Online";
$language["BLOCK_ONTODAY"]="Vandaag Aanwezig";
$language["BLOCK_SHOUTBOX"]="Shout Box";
$language["BLOCK_TOPTORRENTS"]="Top Torrents";
$language["BLOCK_LASTTORRENTS"]="Laatste Torrents";
$language["BLOCK_NEWS"]="Laatste Nieuws";
$language["BLOCK_SERVERLOAD"]="Server Lading";
$language["BLOCK_POLL"]="Poll";
$language["BLOCK_SEEDWANTED"]="Torrents Zonder Seeders";
$language["BLOCK_PAYPAL"]="Steun Ons";
$language["WELCOME_LASTUSER"]="Welkom op onze tracker ";
$language["BLOCK_MAINTRACKERTOOLBAR"]="Main Tracker Toolbar";
$language["BLOCK_MAINUSERTOOLBAR"]="Main User Toolbar";
$language["BLOCK_MINCLASSVIEW"]="Minimum level dat het blok kan zien";
$language["BLOCK_MAXCLASSVIEW"]="Maximum level dat het blok kan zien";
?>