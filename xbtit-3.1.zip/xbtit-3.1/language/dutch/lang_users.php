<?php

// DUTCH USERS.PHP FILE

$language["FIND_USER"]       = "Vind Gebruiker";
$language["USER_LEVEL"]      = "Gebruikerslevel";
$language["ALL"]             = "Alle";
$language["SEARCH"]          = "Zoek";
$language["USER_NAME"]       = "Gebruikersnaam";
$language["USER_LEVEL"]      = "Gebruikerslevel";
$language["USER_JOINED"]     = "Lid geworden op";
$language["USER_LASTACCESS"] = "Laatst online";
$language["USER_COUNTRY"]    = "Land";
$language["RATIO"]           = "Ratio";
$language["USERS_PM"]        = "PM";
$language["EDIT"]            = "Verander";
$language["DELETE"]          = "Verwijder";
$language["NO_USERS_FOUND"]  = "Geen leden gevonden!";
$language["UNKNOWN"]         = "Onbekend";
?>