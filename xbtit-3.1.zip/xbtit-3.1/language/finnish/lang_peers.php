<?php
$language["PEER_PROGRESS"]="Edityminen";
$language["PEER_COUNTRY"]="Maa";
$language["PEER_PORT"]="Portti";
$language["PEER_STATUS"]="Tila";
$language["PEER_CLIENT"]="Clientti";
$language["NO_PEERS"]="Ei yhteyksi&auml;";
?>