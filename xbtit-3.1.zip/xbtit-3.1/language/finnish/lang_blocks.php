<?php
$language["BLOCK_USER"]="K&auml;ytt&auml;j&auml;tiedot";
$language["BLOCK_INFO"]="Trakkerin tiedot";
$language["BLOCK_MENU"]="P&auml;&auml;valikko";
$language["BLOCK_CLOCK"]="Kello";
$language["BLOCK_FORUM"]="Foorumi";
$language["BLOCK_LASTMEMBER"]="Viimeisin j&auml;sen";
$language["BLOCK_ONLINE"]="Kirjautuneena";
$language["BLOCK_ONTODAY"]="T&auml;n&auml;&auml;n";
$language["BLOCK_SHOUTBOX"]="Huutolaatikko";
$language["BLOCK_TOPTORRENTS"]="Parhaat torrentit";
$language["BLOCK_LASTTORRENTS"]="Uusimmat torrentit";
$language["BLOCK_NEWS"]="Uutiset";
$language["BLOCK_SERVERLOAD"]="Palvelimen kuorma";
$language["BLOCK_POLL"]="Kysely";
$language["BLOCK_SEEDWANTED"]="Torrentit jotka kaipaavat jakajaa";
$language["BLOCK_PAYPAL"]="Tue meit&auml;";
$language["BLOCK_MAINTRACKERTOOLBAR"]="Trakkerin p&auml;&auml;valikko";
$language["BLOCK_MAINUSERTOOLBAR"]="K&auml;ytt&auml;j&auml;n p&auml;&auml;valikko";
$language["WELCOME_LASTUSER"]=" Tervetuloa (SIVUN NIMI) ";
$language["BLOCK_MINCLASSVIEW"]="Matalin arvo jolle n&auml;ytet&auml;&auml;n";
$language["BLOCK_MAXCLASSVIEW"]="Korkein arvo jolle n&auml;ytet&auml;&auml;n";
?>