<?php
$language['NOT_SHA']='SHA1 function not available. You need PHP 4.3.0 or better.';
$language['NOT_AUTHORIZED_UPLOAD']='আপনার upload করার অনুমতি নেই!';
$language['FILE_UPLOAD_ERROR_1']='uploaded file এঁর মধ্যে সমস্যা পাওয়া গেছে';
$language['FILE_UPLOAD_ERROR_3']='ফাইল এর সাইজ শূন্য';
$language['FACOLTATIVE']='অতিরিক্ত';
$language['FILE_UPLOAD_ERROR_2']='File Upload সমস্যা';
$language['ERR_PARSER']='আপনার টোরেন ফাইল ঠিক মত তৈরি হয়নি.';
$language['WRITE_CATEGORY']='আপনার টোরেন্ট এর জন্য বিষয় নির্বাচন করুন...';
$language['DOWNLOAD']='ডাউনলোড';
$language['MSG_UP_SUCCESS']='Upload সফল হয়েছে! আপনার টোরেন্ট যোগ করা হয়েছে.';
$language['MSG_DOWNLOAD_PID']='PID system সচল আপনার টরেন্ট PID সিস্টেম এর মাধ্যমে বুঝে নিন';
$language['EMPTY_DESCRIPTION']='আপনার নিশ্চয় বর্ণনা দিতে হবে!';
$language['EMPTY_ANNOUNCE']='Announce পুরন করা হয়নি';
$language['FILE_UPLOAD_ERROR_1']='আপনার টোরেন ফাইল ঠিক মত তৈরি হয়নি';
$language['FILE_UPLOAD_ERROR_2']='uploaded file এঁর মধ্যে সমস্যা পাওয়া গেছে';
$language['FILE_UPLOAD_ERROR_3']='ফাইল এর সাইজ শূন্য';
$language['NO_SHA_NO_UP']='File uploading not available - no SHA1 function.';
$language['NOT_SHA']='SHA1 function not available. You need PHP 4.3.0 or better.';
$language['ERR_PARSER']='ফাইল এর সাইজ শূন্য.';
$language['WRITE_CATEGORY']='আপনার টোরেন্ট এর জন্য বিষয় নির্বাচন করুন...';
$language['ERR_HASH']='Info hash MUST be exactly 40 hex bytes.';
$language['ERR_EXTERNAL_NOT_ALLOWED']='বাইরের torrents not allowed';
$language['ERR_MOVING_TORR']='Error moving torrent...';
$language['ERR_ALREADY_EXIST']='আপনার দাওয়া টরেন্ট আমাদের কাছে আগে থেকে আছে।ধন্যবাদ.';
$language['MSG_DOWNLOAD_PID']='PID system active get your torrent with your PID';
$language['MSG_UP_SUCCESS']='Upload সফল হয়েছে! আপনার টোরেন্ট যোগ করা হয়েছে.';
?>