<?php

// USERDETAILS.PHP LANGUAGE FILE

$language['USERNAME']           = 'ব্যাবহারকারির নাম';
$language['EMAIL']              = 'ইমেইল ঠিকানা';
$language['LAST_IP']            = 'সর্বশেষ আই পি';
$language['USER_LEVEL']         = 'পদ';
$language['USER_JOINED']        = 'আমাদের সাথে যোগদান';
$language['USER_LASTACCESS']    = 'সর্বশেষ দেখা';
$language['PEER_COUNTRY']       = 'দেশ';
$language['USER_LOCAL_TIME']    = 'সদস্যয়ের আঞ্চলিক সময়';
$language['DOWNLOADED']         = 'ডাউনলোড';
$language['UPLOADED']           = 'আপলোড';
$language['RATIO']              = 'মূল্যায়ন পয়েন্ট';
$language['FORUM']              = 'ফোরাম';
$language['POSTS']              = 'মন্তব্য';
$language['POSTS_PER_DAY']      = '%s লিখে পোস্ট প্রতিদিন';
$language['TORRENTS']           = 'টরেন্টস';
$language['FILE']               = 'ফাইল';
$language['ADDED']              = 'যোগ করা হয়েছে';
$language['SIZE']               = 'আকার';
$language['SHORT_S']            = 'S সীডার';
$language['SHORT_L']            = 'L ডাউনলোড চলছে';
$language['SHORT_C']            = 'C ডাউনলোড সফল';
$language['NO_TORR_UP_USER']    = 'কোন টরেন্ট আপলোড করেনি!';
$language['ACTIVE_TORRENT']     = 'বর্তমান টরেন্ট';
$language['PEER_STATUS']        = 'বর্তমান অবস্থা';
$language['NO_ACTIVE_TORR']     = 'কোন সচল টরেন্ট নেই';
$language['PEER_CLIENT']        = 'সাহাজ্জকারী';
$language['EDIT']               = 'সম্পাদনা';
$language['DELETE']             = 'মুছে ফেলুন';
$language['PM']                 = 'চিঠি';
$language['BACK']               = 'আগের অবস্থান';
$language['NO_HISTORY']         = 'বর্তমান কোন তথ্য নেই...';
$language['GUEST_DETAILS']      = 'You can\'t view the details for the Guest account!';
?>