<?php
$language['ERR_NO_TITLE']='বিষয় ছাড়া কোন পোস্ট এর অনুমতি নেই';
?>