<?php
$language["NOT_SHA"]="SHA1 funkció nem elérhető. Szükséged van a PHP 4.3.0 vagy újabb verzóra..";
$language["NOT_AUTHORIZED_UPLOAD"]="Nincs jogosultságod a feltöltéshez!<br><br>Klick <a class=altlink href=uploaderrequest.php>ide</a> hogy feltöltő lehess!";
$language["FILE_UPLOAD_ERROR_1"]="A feltöltött fájl nem olvasható";
$language["FILE_UPLOAD_ERROR_3"]="A fájl 0 méretű";
$language["FACOLTATIVE"]="választható";
$language["FILE_UPLOAD_ERROR_2"]="File Feltöltési hiba";
$language["ERR_PARSER"]="Úgy tűnik hiba van a torrentedben. A parser elutasította.";
$language["WRITE_CATEGORY"]="Meg kell adnod a torrent kategóriáját...";
$language["DOWNLOAD"]="Letöltés";
$language["MSG_UP_SUCCESS"]="Feltöltés kész! A torrent hozzáadva.";
$language["MSG_DOWNLOAD_PID"]="Azonosítókulcs aktív a torrent elérése a azonosítókulccsal";
$language["EMPTY_DESCRIPTION"]="Nincs leírás!";
$language["EMPTY_ANNOUNCE"]="Announce is empty";
$language["FILE_UPLOAD_ERROR_1"]="A feltöltött fájl nem olvasható";
$language["FILE_UPLOAD_ERROR_2"]="File Feltöltési hiba";
$language["FILE_UPLOAD_ERROR_3"]="A fájl 0 méretű";
$language["NO_SHA_NO_UP"]="Fájl feltöltés nem elérhető - nincs SHA1 funkció.";
$language["NOT_SHA"]="SHA1 funkció nem elérhető. Szükséged van a PHP 4.3.0 vagy újabb verzóra.";
$language["ERR_PARSER"]="Úgy tűnik hiba van a torrentedben. A parser elutasította.";
$language["WRITE_CATEGORY"]="Meg kell adnod a torrent kategóriáját...";
$language["ERR_HASH"]="Info hash nem éri el a 40 hex bytes.";
$language["ERR_EXTERNAL_NOT_ALLOWED"]="Külső torrentek nem megengedettek";
$language["ERR_MOVING_TORR"]="Hiba a torrent mozgatásakor...";
$language["ERR_ALREADY_EXIST"]="Már van ilyen torrent!";
$language["MSG_DOWNLOAD_PID"]="Azonosítókulcs aktív a torrent elérése a azonosítókulccsal";
$language["MSG_UP_SUCCESS"]="Feltöltés kész! A torrent hozzáadva.";
?>