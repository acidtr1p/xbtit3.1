<?php

// VIEWNEWS.PHP LANGUAGE FILE

$language["POSTED_BY"]   = "Írta";
$language["POSTED_DATE"] = "Hozzáadva";
$language["TITLE"]       = "Cím";
$language["ADD"]         = "Hozzáad";
?>