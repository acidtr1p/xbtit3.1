<?php
$language["ERR_NO_EMAIL"]="Be kell írnod az email címedet";
$language["ERR_INV_EMAIL"]="Írd be a regisztrált email címedet";
$language["ERR_NO_CAPTCHA"]="Írd be a képkódot";
$language["IMAGE_CODE"]="Képkód";
$language["SECURITY_CODE"]="Adj választ a kérdésre";
$language["RECOVER_EMAIL_1"]="\nValaki erre az email címre kérte a jelszó megváltoztatását, reméljük jó kezekbe került az email. (%s) \n\nA kérés kezdeményezőjének IP címe a következő volt: %s.\n\n Kérlek erre az üzenetre ne válaszolj, ezt a rendszer küldte!\n\nHa valóban meg szeretnéd változtatni a jelszavad, kövesd az alábbi linket:\n\n%s\n\nMiután ezt megtetted, kapsz egy újabb emailt a felhasználói neveddel, és jelszavaddal.\n--\n%s";
$language["RECOVER_EMAIL_2"]="\nKérésedre a következő jelszót hoztuk létre.\n\nMostmár bejelentkezhetsz az oldalra:\n\n    Felhasználói neved: %s\n    Jelszavad: %s\n\nA profilodban meg tudod változtatni ezt a jelszót egy számodra könnyebben megjegyezhetőre. \n\nDe arra figyelj hogy legközelebb ne felejtsd el a jelszavad! Kattints az alul található linkre a bejelentkezéshez:\n\n %s\n\n--\n%s";
?>