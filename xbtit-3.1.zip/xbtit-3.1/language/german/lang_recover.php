<?php
$language["ERR_NO_EMAIL"]="Du musst eine Email Adresse angeben";
$language["ERR_INV_EMAIL"]="Du musst eine gültige Email Adresse angeben";
$language["ERR_NO_CAPTCHA"]="Du musst den Code aus dem Bild eingeben";
$language["IMAGE_CODE"]="Bildcode";
$language["SECURITY_CODE"]="Beantworte die Frage";
$language["RECOVER_EMAIL_1"]="\nJemand, hoffentlich Sie, hat den Wunsch das Passwort für dieses Konto, mit Angabe dieser Email Adresse, zu ändern (%s) \n\nDie Anfrage zur Änderung erfolgte von %s.\n\nFalls Sie dies nicht getan haben, ignorieren Sie bitte diese Email. Bitte antworten Sie nicht auf diese Email.\n\nWollen Sie diese Anfrage bestätigen, benutzen Sie den folgenden Link:\n\n%s\n\nNach Ihrer Bestätigung wird Ihr aktuelles Passwort gelöscht und ein neues, per Email, an Sie gesandt.\n--\n%s";
$language["RECOVER_EMAIL_2"]="\nAuf Ihre Anfrage hin haben wir ein neues Passwort für Sie generiert.\n\nDie bei uns gespeicherten Informationen über Ihr Konto sind:\n\n    Benutzername: %s\n    Passwort: %s\n\nSie können sich einwählen bei %s\n\n--\n%s";
?>