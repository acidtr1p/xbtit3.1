<?php
$language["PEER_PROGRESS"]="Progression";
$language["PEER_COUNTRY"]="Pays";
$language["PEER_PORT"]="Port";
$language["PEER_STATUS"]="Statut";
$language["PEER_CLIENT"]="Client";
$language["NO_PEERS"]="Aucun historique à afficher";
?>