<?php
$language["NOT_SHA"]="La fonction SHA1 n'est pas disponible. Vous avez besoin de PHP 4.3.0 ou supérieur.";
$language["NOT_AUTHORIZED_UPLOAD"]="Vous n'êtes pas autorisé à envoyer !";
$language["FILE_UPLOAD_ERROR_1"]="Impossible de lire le fichier envoyé";
$language["FILE_UPLOAD_ERROR_2"]="Erreur d'upload du fichier";
$language["FILE_UPLOAD_ERROR_3"]="Le fichier à une taille de 0";
$language["FACOLTATIVE"]="optionnel";
$language["FILE_UPLOAD_ERROR_2"]="Erreur d'envoi du fichier";
$language["ERR_PARSER"]="Il semble y avoir une erreur dans votre torrent. Le parser ne l'accepte pas.";
$language["WRITE_CATEGORY"]="Vous devez spécifier une catégorie...";
$language["DOWNLOAD"]="Téléchargé";
$language["MSG_UP_SUCCESS"]="Envoi réussi ! Le torrent à bien été ajouté.";
$language["MSG_DOWNLOAD_PID"]="Le PID est activé, merci de vous servir de votre PID";
$language["EMPTY_DESCRIPTION"]="Vous devez entrer une description !";
$language["EMPTY_ANNOUNCE"]="L'annonce est vide !";
$language["NO_SHA_NO_UP"]="Fichier de téléchargement non disponible - pas de fonction SHA1.";
$language["ERR_HASH"]="L'info hash DOIT être exactement de 40 hex octets.";
$language["ERR_EXTERNAL_NOT_ALLOWED"]="Les torrents externes ne sont pas acceptés";
$language["ERR_MOVING_TORR"]=" Erreur de déplacement du torrent...";
$language["ERR_ALREADY_EXIST"]="Ce torrent existent peut-être déja.";
?>