<?php

// ENGLISH USERS.PHP FILE

$language["FIND_USER"]       = "Trouver un utilisateur";
$language["USER_LEVEL"]      = "Niveau";
$language["ALL"]             = "Tout";
$language["SEARCH"]          = "Rechercher";
$language["USER_NAME"]       = "Nom";
$language["USER_JOINED"]     = "Inscrit le";
$language["USER_LASTACCESS"] = "Dernière connexion";
$language["USER_COUNTRY"]    = "Pays";
$language["RATIO"]           = "Ratio";
$language["USERS_PM"]        = "MP";
$language["EDIT"]            = "Èditer";
$language["DELETE"]          = "Supprimer";
$language["NO_USERS_FOUND"]  = "Pas d'utilisateur trouvé !";
$language["UNKNOWN"]         = "Inconnu";
?>