<?php
// Traduzione eseguita da mOOn, con il QCheck di Laurianti.
//Un grazie anche a Confe, e a chi si è prodigato nel testare il Tracker
// Per qualsiasi info ci trovate su http://dpwsmedia.com
$language["ACCOUNT_CREATED"]="Account creato";
$language["USER_NAME"]="Utente";
$language["USER_PWD_AGAIN"]="Ripeti password";
$language["USER_PWD"]="Password";
$language["USER_STYLE"]="Stile";
$language["USER_LANGUE"]="Linguaggio";
$language["IMAGE_CODE"]="Codice d'immagine";
$language["INSERT_USERNAME"]="Devi inserire il nome utente!";
$language["INSERT_PASSWORD"]="Devi inserire la password!";
$language["DIF_PASSWORDS"]="La password non corrisponde!";
$language["ERR_NO_EMAIL"]="Devi inserire un indirizzo di posta elettronica valido";
$language["USER_EMAIL_AGAIN"]="Ripeti l'email";
$language["ERR_NO_EMAIL_AGAIN"]="Ripeti l'email";
$language["DIF_EMAIL"]="L'indirizzo di posta elettronica non corrisponde!";
$language["SECURITY_CODE"]="Domanda di sicurezza";
# Password strength
$language["WEEK"]="Debole";
$language["MEDIUM"]="Medio";
$language["SAFE"]="Sicuro";
$language["STRONG"]="Forte";
?>