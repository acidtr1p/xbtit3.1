<?php

$dbhost = "";
$dbuser = "";
$dbpass = "";
$database = "";
$TABLE_PREFIX = "";
$mySecret  = "";

?>