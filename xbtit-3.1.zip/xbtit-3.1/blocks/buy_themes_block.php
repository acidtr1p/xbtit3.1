<?php
?>
<table align="center" width="50%" border="0" cellpadding="2" cellspacing="2">
<tr valign="top">
<center><b>When buying a theme it may take upto 24 hrs. before I can send it out to you because i do have a real day job.<br />
</b></center>	
<td style="border-width : 0px;">
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="L4JASKKHCK54N">
<table>
<tr><td><input type="hidden" name="on0" value="TTC Themes for €20.00">TTC Themes for €20.00</td></tr><tr><td><select name="os0">
	<option value="Black_Neon">Black_Neon €20.00 EUR</option>
	<option value="Cherry_Splash">Cherry_Splash €20.00 EUR</option>
	<option value="Fallen">Fallen €20.00 EUR</option>
	<option value="Ripples">Ripples €20.00 EUR</option>
	<option value="Rustic_Moon">Rustic_Moon €20.00 EUR</option>
	<option value="Splatter">Splatter €20.00 EUR</option>
	<option value="SR-5">SR-5 €20.00 EUR</option>
	<option value="Simplicity">Simplicity €20.00 EUR</option>
</select> </td></tr>
</table><br />
<input type="hidden" name="currency_code" value="EUR">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
</td>
<td style="border-width : 0px;">
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="2N5BUUQRVGRME">
<table>
<tr><td><input type="hidden" name="on0" value="TTC Themes for €50.00">TTC Themes for €50.00</td></tr><tr><td><select name="os0">
	<option value="Black-n-Blue">Black-n-Blue €50.00 EUR</option>
	<option value="Deep Sea">Deep Sea €50.00 EUR</option>
	<option value="Fire & Ice">Fire & Ice €50.00 EUR</option>
	<option value="Haze Purple">Haze Purple €50.00 EUR</option>
	<option value="Hells Gate">Hells Gate €50.00 EUR</option>
	<option value="Mother Earth">Mother Earth €50.00 EUR</option>
</select> </td></tr>
</table><br />
<input type="hidden" name="currency_code" value="EUR">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>





</td>
</tr>
</table>
<center><b>These themes works on xbtit 2.4.0 & below. <br />If you want any theme converted for xbiti 2.5.x there will be a cost of €15 euro over  the cost of the theme.<br />
</b></center>	
</div>







