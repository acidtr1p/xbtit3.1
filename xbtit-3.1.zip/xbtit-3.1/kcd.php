<?php
phpinfo ();
?>